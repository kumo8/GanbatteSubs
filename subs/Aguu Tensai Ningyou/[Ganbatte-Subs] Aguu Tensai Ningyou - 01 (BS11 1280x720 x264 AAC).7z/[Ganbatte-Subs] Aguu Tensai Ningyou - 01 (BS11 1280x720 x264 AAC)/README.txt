If you are using the MPV video player [https://mpv.io/], the subtitle file will work out of the box.

If you are not using MPV, you will need to install the font(s) bundled within this .7z archive.
